"use strict"

// Login funct
function login() {
    var element = document.getElementById("login-modal");
    element.style.display = null;
}

function closeLogin() {
    var element = document.getElementById("login-modal");
    element.style.display = "none";
}
// End Login funct